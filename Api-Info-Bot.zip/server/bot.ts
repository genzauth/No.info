import { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } from "discord.js";
import { storage } from "./storage";

// Helper to fetch data
async function fetchMobileInfo(number: string) {
  try {
    const response = await fetch(`https://api.subhxcosmo.in/api?key=MANI&type=mobile&term=${number}`);
    if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching mobile info:", error);
    return null;
  }
}

export class DiscordBot {
  private client: Client;
  private isOnline: boolean = false;

  constructor() {
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
      ],
    });

    this.setupEvents();
  }

  private setupEvents() {
    this.client.once("ready", () => {
      console.log(`Logged in as ${this.client.user?.tag}!`);
      this.isOnline = true;
      this.registerCommands();
    });

    this.client.on("interactionCreate", async (interaction) => {
      if (!interaction.isChatInputCommand()) return;

      if (interaction.commandName === "mobile") {
        await interaction.deferReply();
        
        const number = interaction.options.getString("number");
        
        if (!number) {
            await interaction.editReply("Please provide a mobile number.");
            return;
        }

        try {
            const info = await fetchMobileInfo(number);
            
            // Log the query
            await storage.logQuery({
                userId: interaction.user.id,
                username: interaction.user.username,
                mobileNumber: number,
                apiResponse: info || { error: "Failed to fetch" },
            });

            if (!info) {
                await interaction.editReply("Failed to fetch information for that number.");
                return;
            }

            // Format response nicely
            // Assuming the API returns JSON, we'll just format it as a code block for now
            // or iterate keys if it's a flat object.
            // Since we don't know the exact response structure, we'll pretty print the JSON.
            const formattedInfo = JSON.stringify(info, null, 2);
            
            // Discord message limit is 2000 chars
            if (formattedInfo.length > 1900) {
                 await interaction.editReply(`Info found but too long to display:\n\`\`\`json\n${formattedInfo.substring(0, 1900)}...\n\`\`\``);
            } else {
                 await interaction.editReply(`**Mobile Info for ${number}:**\n\`\`\`json\n${formattedInfo}\n\`\`\``);
            }

        } catch (error) {
            console.error("Command error:", error);
            await interaction.editReply("An error occurred while processing your request.");
        }
      }
    });
    
    // Also support a text command fallback !mobile <number>
    this.client.on("messageCreate", async (message) => {
        if (message.author.bot) return;
        
        if (message.content.startsWith("!mobile ")) {
            const number = message.content.split(" ")[1];
            if (!number) return;
            
            const info = await fetchMobileInfo(number);
             // Log the query
            await storage.logQuery({
                userId: message.author.id,
                username: message.author.username,
                mobileNumber: number,
                apiResponse: info || { error: "Failed to fetch" },
            });

            if (info) {
                 const formattedInfo = JSON.stringify(info, null, 2);
                 message.reply(`**Mobile Info for ${number}:**\n\`\`\`json\n${formattedInfo}\n\`\`\``);
            } else {
                message.reply("Failed to fetch info.");
            }
        }
    });
  }

  private async registerCommands() {
      if (!process.env.DISCORD_TOKEN || !process.env.DISCORD_CLIENT_ID) {
          console.error("Missing Discord credentials for slash commands.");
          return;
      }

      const commands = [
          new SlashCommandBuilder()
            .setName("mobile")
            .setDescription("Lookup mobile number information")
            .addStringOption(option => 
                option.setName("number")
                    .setDescription("The mobile number to lookup")
                    .setRequired(true)
            ),
      ];

      const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

      try {
          console.log("Started refreshing application (/) commands.");
          await rest.put(
              Routes.applicationCommands(process.env.DISCORD_CLIENT_ID),
              { body: commands },
          );
          console.log("Successfully reloaded application (/) commands.");
      } catch (error) {
          console.error(error);
      }
  }

  public async start() {
    if (!process.env.DISCORD_TOKEN) {
      console.warn("DISCORD_TOKEN not set, bot will not start.");
      return;
    }
    try {
        await this.client.login(process.env.DISCORD_TOKEN);
    } catch (e) {
        console.error("Failed to login to Discord:", e);
        this.isOnline = false;
    }
  }

  public getStatus() {
      return {
          status: this.isOnline ? "online" : "offline",
          ping: this.client.ws.ping,
          uptime: this.client.uptime,
      };
  }
}

export const bot = new DiscordBot();
