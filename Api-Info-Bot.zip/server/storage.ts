import { db } from "./db";
import { queryLogs, type InsertQueryLog, type QueryLog } from "@shared/schema";
import { desc } from "drizzle-orm";

export interface IStorage {
  getQueryLogs(): Promise<QueryLog[]>;
  logQuery(log: InsertQueryLog): Promise<QueryLog>;
}

export class DatabaseStorage implements IStorage {
  async getQueryLogs(): Promise<QueryLog[]> {
    return await db.select().from(queryLogs).orderBy(desc(queryLogs.queriedAt)).limit(50);
  }

  async logQuery(log: InsertQueryLog): Promise<QueryLog> {
    const [entry] = await db.insert(queryLogs).values(log).returning();
    return entry;
  }
}

export const storage = new DatabaseStorage();
