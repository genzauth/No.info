import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { bot } from "./bot";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Logs API
  app.get(api.logs.list.path, async (req, res) => {
    try {
        const logs = await storage.getQueryLogs();
        res.json(logs);
    } catch (error) {
        console.error("Failed to fetch logs:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
  });

  // Bot Status API
  app.get(api.bot.status.path, (req, res) => {
    try {
        const status = bot.getStatus();
        res.json({
            status: status.status as "online" | "offline" | "error",
            uptime: status.uptime ?? 0,
            ping: status.ping,
        });
    } catch (error) {
        console.error("Failed to get bot status:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
  });

  // Start the bot
  console.log("Starting Discord bot...");
  bot.start().catch((err) => {
      console.error("Failed to start Discord bot:", err);
  });

  return httpServer;
}
