import { Layout } from "@/components/layout";
import { LogsTable } from "@/components/logs-table";
import { Loader, ErrorState } from "@/components/ui/loader";
import { useQueryLogs } from "@/hooks/use-bot";

export default function LogsPage() {
  const { data: logs, isLoading, error } = useQueryLogs();

  if (isLoading) return <Layout><Loader /></Layout>;
  if (error) return <Layout><ErrorState message="Could not fetch logs." /></Layout>;

  return (
    <Layout>
      <div className="space-y-2 mb-8">
        <h1 className="text-3xl font-bold tracking-tight">System Logs</h1>
        <p className="text-muted-foreground">Complete history of all bot interactions and API queries.</p>
      </div>
      
      <LogsTable logs={logs || []} />
    </Layout>
  );
}
