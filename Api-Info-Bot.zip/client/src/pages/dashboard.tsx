import { Layout } from "@/components/layout";
import { StatusCard } from "@/components/status-card";
import { LogsTable } from "@/components/logs-table";
import { Loader, ErrorState } from "@/components/ui/loader";
import { useBotStatus, useQueryLogs } from "@/hooks/use-bot";
import { 
  Wifi, 
  Activity, 
  Clock, 
  Database, 
  Server
} from "lucide-react";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { data: status, isLoading: isStatusLoading, error: statusError } = useBotStatus();
  const { data: logs, isLoading: isLogsLoading, error: logsError } = useQueryLogs();

  const isLoading = isStatusLoading || isLogsLoading;
  const isError = statusError || logsError;

  if (isLoading) return <Layout><Loader /></Layout>;
  if (isError) return <Layout><ErrorState message="Could not connect to the bot server. Please ensure the backend is running." /></Layout>;

  // Derived stats
  const totalQueries = logs?.length || 0;
  const uniqueUsers = new Set(logs?.map(l => l.userId)).size;
  const lastActive = logs?.[0]?.queriedAt ? new Date(logs[0].queriedAt) : new Date();

  return (
    <Layout>
      <div className="space-y-2 mb-8">
        <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-white to-white/60 bg-clip-text text-transparent">
          Dashboard Overview
        </h1>
        <p className="text-muted-foreground">Real-time metrics and query logs for CosmoBot.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatusCard
          title="Bot Status"
          value={status?.status === "online" ? "Online" : "Offline"}
          icon={<Wifi className="w-5 h-5" />}
          status={status?.status === "online" ? "success" : "error"}
          trend={status?.status === "online" ? "Active" : "Down"}
        />
        
        <StatusCard
          title="Latency"
          value={`${status?.ping || 0}ms`}
          icon={<Activity className="w-5 h-5" />}
          status={!status?.ping ? "default" : status.ping < 100 ? "success" : status.ping < 300 ? "warning" : "error"}
        />

        <StatusCard
          title="Total Queries"
          value={totalQueries}
          icon={<Database className="w-5 h-5" />}
          status="default"
        />

        <StatusCard
          title="Uptime"
          value={`${Math.floor((status?.uptime || 0) / 3600)}h`}
          icon={<Clock className="w-5 h-5" />}
          trend="Since restart"
          status="default"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="col-span-1 p-6 rounded-2xl bg-gradient-to-br from-purple-900/10 to-blue-900/10 border border-primary/20 relative overflow-hidden group"
        >
          <div className="absolute inset-0 bg-primary/5 group-hover:bg-primary/10 transition-colors duration-500" />
          <div className="relative z-10">
            <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
              <Server className="w-4 h-4 text-primary" />
              Quick Stats
            </h3>
            <div className="space-y-4 mt-4">
              <div className="flex justify-between items-center py-2 border-b border-white/5">
                <span className="text-muted-foreground text-sm">Unique Users</span>
                <span className="font-mono font-bold">{uniqueUsers}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-white/5">
                <span className="text-muted-foreground text-sm">Last Query</span>
                <span className="font-mono text-sm">{logs?.[0] ? new Date(logs[0].queriedAt!).toLocaleTimeString() : "N/A"}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-white/5">
                <span className="text-muted-foreground text-sm">Server Time</span>
                <span className="font-mono text-sm">{new Date().toLocaleTimeString()}</span>
              </div>
            </div>
          </div>
        </motion.div>
        
        <div className="col-span-1 lg:col-span-2 rounded-2xl p-1 bg-gradient-to-br from-border/50 to-border/10">
          <div className="h-full bg-card rounded-xl p-6 relative overflow-hidden">
             <div className="absolute top-0 right-0 p-32 bg-primary/5 rounded-full blur-3xl -mr-16 -mt-16" />
             <h3 className="font-semibold text-lg mb-4 relative z-10">Recent Activity</h3>
             {/* Simple visual bar chart using raw divs since we have a list of logs */}
             <div className="flex items-end gap-2 h-32 relative z-10">
               {logs?.slice(0, 12).reverse().map((log, i) => {
                 // Mock height based on some property to make it look active
                 const height = 30 + (log.id % 70); 
                 return (
                   <motion.div
                     key={log.id}
                     initial={{ height: 0 }}
                     animate={{ height: `${height}%` }}
                     transition={{ delay: i * 0.05 }}
                     className="flex-1 bg-primary/20 hover:bg-primary rounded-t-sm transition-colors cursor-help"
                     title={`Query by ${log.username}`}
                   />
                 );
               })}
             </div>
             <div className="mt-2 text-xs text-muted-foreground text-center">Last 12 Requests Volume</div>
          </div>
        </div>
      </div>

      <LogsTable logs={logs || []} />
    </Layout>
  );
}
