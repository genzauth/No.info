import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

// Types derived from schema
// We manually define them here to match the schema shapes since we can't import server-side types directly in client
// but we use the shared route definitions for validation

export interface QueryLog {
  id: number;
  userId: string;
  username: string;
  mobileNumber: string;
  apiResponse: unknown;
  queriedAt: string | null;
}

export interface BotStatus {
  status: "online" | "offline" | "error";
  uptime?: number;
  ping?: number;
}

export function useBotStatus() {
  return useQuery({
    queryKey: [api.bot.status.path],
    queryFn: async () => {
      const res = await fetch(api.bot.status.path);
      if (!res.ok) throw new Error("Failed to fetch bot status");
      const data = await res.json();
      // Validate using shared Zod schema
      return api.bot.status.responses[200].parse(data) as BotStatus;
    },
    refetchInterval: 5000, // Poll every 5 seconds
  });
}

export function useQueryLogs() {
  return useQuery({
    queryKey: [api.logs.list.path],
    queryFn: async () => {
      const res = await fetch(api.logs.list.path);
      if (!res.ok) throw new Error("Failed to fetch logs");
      const data = await res.json();
      // Validate using shared Zod schema
      return api.logs.list.responses[200].parse(data) as QueryLog[];
    },
    refetchInterval: 10000, // Poll every 10 seconds
  });
}
