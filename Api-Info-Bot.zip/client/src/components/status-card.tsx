import { ReactNode } from "react";
import { motion } from "framer-motion";
import { clsx } from "clsx";

interface StatusCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  trend?: string;
  status?: "default" | "success" | "warning" | "error";
  className?: string;
}

export function StatusCard({ title, value, icon, trend, status = "default", className }: StatusCardProps) {
  const statusColors = {
    default: "text-foreground",
    success: "text-emerald-500",
    warning: "text-amber-500",
    error: "text-rose-500",
  };

  const bgGradients = {
    default: "from-card to-card/50",
    success: "from-emerald-950/20 to-card/50",
    warning: "from-amber-950/20 to-card/50",
    error: "from-rose-950/20 to-card/50",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      className={clsx(
        "relative overflow-hidden rounded-2xl p-6 border border-border/50 bg-gradient-to-br backdrop-blur-sm shadow-lg",
        bgGradients[status],
        className
      )}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="p-3 bg-white/5 rounded-xl border border-white/10 text-primary">
          {icon}
        </div>
        {trend && (
          <span className="text-xs font-mono px-2 py-1 rounded-full bg-white/5 border border-white/10">
            {trend}
          </span>
        )}
      </div>
      
      <h3 className="text-sm font-medium text-muted-foreground mb-1">{title}</h3>
      <div className={clsx("text-3xl font-bold tracking-tight font-sans", statusColors[status])}>
        {value}
      </div>
      
      <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-primary/5 rounded-full blur-3xl" />
    </motion.div>
  );
}
