import { QueryLog } from "@/hooks/use-bot";
import { format } from "date-fns";
import { Search, Eye, Smartphone, User as UserIcon } from "lucide-react";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

export function LogsTable({ logs }: { logs: QueryLog[] }) {
  const [search, setSearch] = useState("");
  const [selectedLog, setSelectedLog] = useState<QueryLog | null>(null);

  const filteredLogs = logs.filter(
    (log) =>
      log.username.toLowerCase().includes(search.toLowerCase()) ||
      log.mobileNumber.includes(search)
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold tracking-tight">Recent Queries</h2>
        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search logs..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-card/50 border border-border/50 rounded-xl pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/50 transition-all placeholder:text-muted-foreground/50"
          />
        </div>
      </div>

      <div className="rounded-2xl border border-border/50 bg-card/30 backdrop-blur-sm overflow-hidden shadow-xl shadow-black/5">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-white/5 text-muted-foreground font-medium border-b border-white/5">
              <tr>
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Mobile Number</th>
                <th className="px-6 py-4">Time</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-muted-foreground">
                    No logs found matching your search.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr
                    key={log.id}
                    className="group hover:bg-white/5 transition-colors duration-150"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
                          <UserIcon className="w-4 h-4 text-primary" />
                        </div>
                        <div className="font-medium text-foreground">{log.username}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 font-mono text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Smartphone className="w-3 h-3" />
                        {log.mobileNumber}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-muted-foreground whitespace-nowrap">
                      {log.queriedAt ? format(new Date(log.queriedAt), "MMM d, h:mm a") : "-"}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => setSelectedLog(log)}
                        className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-primary transition-colors"
                        title="View Details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Dialog open={!!selectedLog} onOpenChange={(open) => !open && setSelectedLog(null)}>
        <DialogContent className="max-w-2xl bg-card border-border/50 shadow-2xl">
          <DialogHeader>
            <DialogTitle>Query Details</DialogTitle>
            <DialogDescription>
              Full API response for request from {selectedLog?.username}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-secondary/30 p-3 rounded-xl border border-border/30">
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Target Number</p>
                <p className="font-mono text-lg font-medium">{selectedLog?.mobileNumber}</p>
              </div>
              <div className="bg-secondary/30 p-3 rounded-xl border border-border/30">
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Timestamp</p>
                <p className="font-mono text-lg font-medium">
                  {selectedLog?.queriedAt ? format(new Date(selectedLog.queriedAt), "HH:mm:ss") : "-"}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Raw API Response</p>
              <div className="bg-black/50 p-4 rounded-xl border border-border/30 font-mono text-xs overflow-auto max-h-[300px]">
                <pre className="text-emerald-400">
                  {selectedLog?.apiResponse ? JSON.stringify(selectedLog.apiResponse, null, 2) : "No data"}
                </pre>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
