import { z } from "zod";
import { queryLogs } from "./schema";

export const api = {
  logs: {
    list: {
      method: "GET" as const,
      path: "/api/logs" as const,
      responses: {
        200: z.array(z.custom<typeof queryLogs.$inferSelect>()),
      },
    },
  },
  bot: {
    status: {
      method: "GET" as const,
      path: "/api/bot/status" as const,
      responses: {
        200: z.object({
          status: z.enum(["online", "offline", "error"]),
          uptime: z.number().optional(),
          ping: z.number().optional(),
        }),
      },
    },
  },
};
