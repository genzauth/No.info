import { pgTable, text, serial, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const queryLogs = pgTable("query_logs", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  username: text("username").notNull(),
  mobileNumber: text("mobile_number").notNull(),
  apiResponse: jsonb("api_response").notNull(),
  queriedAt: timestamp("queried_at").defaultNow(),
});

export const insertQueryLogSchema = createInsertSchema(queryLogs).omit({
  id: true,
  queriedAt: true,
});

export type QueryLog = typeof queryLogs.$inferSelect;
export type InsertQueryLog = z.infer<typeof insertQueryLogSchema>;
